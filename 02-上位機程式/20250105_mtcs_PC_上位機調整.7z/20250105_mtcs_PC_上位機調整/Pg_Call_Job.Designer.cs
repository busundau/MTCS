﻿
namespace SerialHex
{
    partial class Pg_Call_Job
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.radioButton31 = new System.Windows.Forms.RadioButton();
            this.radioButton32 = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton33 = new System.Windows.Forms.RadioButton();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.radioButton35 = new System.Windows.Forms.RadioButton();
            this.radioButton36 = new System.Windows.Forms.RadioButton();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.radioButton38 = new System.Windows.Forms.RadioButton();
            this.radioButton39 = new System.Windows.Forms.RadioButton();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.radioButton41 = new System.Windows.Forms.RadioButton();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.radioButton43 = new System.Windows.Forms.RadioButton();
            this.radioButton44 = new System.Windows.Forms.RadioButton();
            this.radioButton45 = new System.Windows.Forms.RadioButton();
            this.radioButton46 = new System.Windows.Forms.RadioButton();
            this.radioButton47 = new System.Windows.Forms.RadioButton();
            this.radioButton48 = new System.Windows.Forms.RadioButton();
            this.radioButton49 = new System.Windows.Forms.RadioButton();
            this.radioButton50 = new System.Windows.Forms.RadioButton();
            this.radioButton51 = new System.Windows.Forms.RadioButton();
            this.radioButton52 = new System.Windows.Forms.RadioButton();
            this.radioButton53 = new System.Windows.Forms.RadioButton();
            this.radioButton54 = new System.Windows.Forms.RadioButton();
            this.radioButton55 = new System.Windows.Forms.RadioButton();
            this.radioButton56 = new System.Windows.Forms.RadioButton();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.radioButton58 = new System.Windows.Forms.RadioButton();
            this.radioButton59 = new System.Windows.Forms.RadioButton();
            this.radioButton60 = new System.Windows.Forms.RadioButton();
            this.radioButton61 = new System.Windows.Forms.RadioButton();
            this.radioButton62 = new System.Windows.Forms.RadioButton();
            this.radioButton63 = new System.Windows.Forms.RadioButton();
            this.radioButton64 = new System.Windows.Forms.RadioButton();
            this.radioButton65 = new System.Windows.Forms.RadioButton();
            this.radioButton66 = new System.Windows.Forms.RadioButton();
            this.radioButton67 = new System.Windows.Forms.RadioButton();
            this.radioButton68 = new System.Windows.Forms.RadioButton();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(548, 92);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(352, 747);
            this.richTextBox1.TabIndex = 36;
            this.richTextBox1.Text = "";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox29);
            this.panel4.Controls.Add(this.textBox28);
            this.panel4.Controls.Add(this.textBox27);
            this.panel4.Controls.Add(this.textBox26);
            this.panel4.Controls.Add(this.textBox25);
            this.panel4.Controls.Add(this.textBox24);
            this.panel4.Controls.Add(this.textBox23);
            this.panel4.Controls.Add(this.textBox22);
            this.panel4.Controls.Add(this.textBox21);
            this.panel4.Controls.Add(this.textBox20);
            this.panel4.Controls.Add(this.textBox19);
            this.panel4.Controls.Add(this.textBox17);
            this.panel4.Controls.Add(this.textBox16);
            this.panel4.Controls.Add(this.textBox15);
            this.panel4.Controls.Add(this.textBox14);
            this.panel4.Controls.Add(this.textBox13);
            this.panel4.Controls.Add(this.textBox12);
            this.panel4.Controls.Add(this.textBox11);
            this.panel4.Controls.Add(this.textBox10);
            this.panel4.Controls.Add(this.textBox9);
            this.panel4.Controls.Add(this.textBox8);
            this.panel4.Controls.Add(this.textBox7);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panel3);
            this.panel4.Controls.Add(this.panel2);
            this.panel4.Controls.Add(this.panel1);
            this.panel4.Controls.Add(this.button4);
            this.panel4.Controls.Add(this.button5);
            this.panel4.Controls.Add(this.button6);
            this.panel4.Controls.Add(this.button7);
            this.panel4.Controls.Add(this.textBox6);
            this.panel4.Controls.Add(this.textBox5);
            this.panel4.Controls.Add(this.textBox4);
            this.panel4.Controls.Add(this.textBox3);
            this.panel4.Controls.Add(this.textBox2);
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Location = new System.Drawing.Point(8, 92);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(518, 688);
            this.panel4.TabIndex = 43;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(17, 258);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(153, 24);
            this.label11.TabIndex = 72;
            this.label11.Text = "Item_Job_ID_P";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(209, 258);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(174, 24);
            this.label10.TabIndex = 71;
            this.label10.Text = "Choice_Job_ID_P";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.radioButton30);
            this.panel5.Controls.Add(this.radioButton29);
            this.panel5.Controls.Add(this.radioButton28);
            this.panel5.Controls.Add(this.radioButton27);
            this.panel5.Location = new System.Drawing.Point(412, 289);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(82, 114);
            this.panel5.TabIndex = 70;
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.radioButton30.Location = new System.Drawing.Point(17, 77);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(46, 16);
            this.radioButton30.TabIndex = 69;
            this.radioButton30.TabStop = true;
            this.radioButton30.Text = "Gray";
            this.radioButton30.UseVisualStyleBackColor = true;
            this.radioButton30.CheckedChanged += new System.EventHandler(this.radioButton30_CheckedChanged_1);
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.radioButton29.Location = new System.Drawing.Point(17, 55);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(42, 16);
            this.radioButton29.TabIndex = 68;
            this.radioButton29.TabStop = true;
            this.radioButton29.Text = "Red";
            this.radioButton29.UseVisualStyleBackColor = true;
            this.radioButton29.CheckedChanged += new System.EventHandler(this.radioButton29_CheckedChanged_1);
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.radioButton28.Location = new System.Drawing.Point(16, 31);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(43, 16);
            this.radioButton28.TabIndex = 67;
            this.radioButton28.TabStop = true;
            this.radioButton28.Text = "blue";
            this.radioButton28.UseVisualStyleBackColor = true;
            this.radioButton28.CheckedChanged += new System.EventHandler(this.radioButton28_CheckedChanged_1);
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Location = new System.Drawing.Point(16, 9);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(57, 16);
            this.radioButton27.TabIndex = 66;
            this.radioButton27.TabStop = true;
            this.radioButton27.Text = "Default";
            this.radioButton27.UseVisualStyleBackColor = true;
            this.radioButton27.CheckedChanged += new System.EventHandler(this.radioButton27_CheckedChanged_1);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButton68);
            this.panel3.Controls.Add(this.radioButton67);
            this.panel3.Controls.Add(this.radioButton66);
            this.panel3.Controls.Add(this.radioButton65);
            this.panel3.Controls.Add(this.radioButton64);
            this.panel3.Controls.Add(this.radioButton63);
            this.panel3.Controls.Add(this.radioButton62);
            this.panel3.Controls.Add(this.radioButton61);
            this.panel3.Controls.Add(this.radioButton60);
            this.panel3.Controls.Add(this.radioButton59);
            this.panel3.Controls.Add(this.radioButton58);
            this.panel3.Controls.Add(this.radioButton57);
            this.panel3.Controls.Add(this.radioButton56);
            this.panel3.Controls.Add(this.radioButton55);
            this.panel3.Controls.Add(this.radioButton54);
            this.panel3.Controls.Add(this.radioButton53);
            this.panel3.Controls.Add(this.radioButton52);
            this.panel3.Controls.Add(this.radioButton51);
            this.panel3.Controls.Add(this.radioButton50);
            this.panel3.Controls.Add(this.radioButton49);
            this.panel3.Controls.Add(this.radioButton10);
            this.panel3.Controls.Add(this.radioButton17);
            this.panel3.Controls.Add(this.radioButton18);
            this.panel3.Controls.Add(this.radioButton19);
            this.panel3.Controls.Add(this.radioButton20);
            this.panel3.Controls.Add(this.radioButton22);
            this.panel3.Controls.Add(this.radioButton21);
            this.panel3.Controls.Add(this.radioButton9);
            this.panel3.Location = new System.Drawing.Point(237, 297);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(161, 237);
            this.panel3.TabIndex = 65;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(42, 7);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(29, 16);
            this.radioButton10.TabIndex = 59;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "8";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(13, 8);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(29, 16);
            this.radioButton17.TabIndex = 58;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "1";
            this.radioButton17.UseVisualStyleBackColor = true;
            this.radioButton17.CheckedChanged += new System.EventHandler(this.radioButton17_CheckedChanged_1);
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(13, 29);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(29, 16);
            this.radioButton18.TabIndex = 57;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "2";
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(13, 51);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(29, 16);
            this.radioButton19.TabIndex = 56;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "3";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(13, 73);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(29, 16);
            this.radioButton20.TabIndex = 55;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "4";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(13, 117);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(29, 16);
            this.radioButton22.TabIndex = 53;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "6";
            this.radioButton22.UseVisualStyleBackColor = true;
            this.radioButton22.CheckedChanged += new System.EventHandler(this.radioButton22_CheckedChanged_1);
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(13, 95);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(29, 16);
            this.radioButton21.TabIndex = 54;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "5";
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButton48);
            this.panel2.Controls.Add(this.radioButton47);
            this.panel2.Controls.Add(this.radioButton46);
            this.panel2.Controls.Add(this.radioButton45);
            this.panel2.Controls.Add(this.radioButton44);
            this.panel2.Controls.Add(this.radioButton43);
            this.panel2.Controls.Add(this.radioButton42);
            this.panel2.Controls.Add(this.radioButton41);
            this.panel2.Controls.Add(this.radioButton40);
            this.panel2.Controls.Add(this.radioButton39);
            this.panel2.Controls.Add(this.radioButton38);
            this.panel2.Controls.Add(this.radioButton37);
            this.panel2.Controls.Add(this.radioButton36);
            this.panel2.Controls.Add(this.radioButton35);
            this.panel2.Controls.Add(this.radioButton34);
            this.panel2.Controls.Add(this.radioButton33);
            this.panel2.Controls.Add(this.radioButton26);
            this.panel2.Controls.Add(this.radioButton25);
            this.panel2.Controls.Add(this.radioButton24);
            this.panel2.Controls.Add(this.radioButton23);
            this.panel2.Controls.Add(this.radioButton12);
            this.panel2.Controls.Add(this.radioButton11);
            this.panel2.Controls.Add(this.radioButton8);
            this.panel2.Controls.Add(this.radioButton7);
            this.panel2.Controls.Add(this.radioButton6);
            this.panel2.Controls.Add(this.radioButton5);
            this.panel2.Controls.Add(this.radioButton4);
            this.panel2.Controls.Add(this.radioButton3);
            this.panel2.Location = new System.Drawing.Point(21, 294);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(151, 237);
            this.panel2.TabIndex = 64;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(13, 139);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(29, 16);
            this.radioButton9.TabIndex = 55;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "7";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged_1);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(13, 124);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(29, 16);
            this.radioButton8.TabIndex = 54;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "6";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(13, 102);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(29, 16);
            this.radioButton7.TabIndex = 53;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "5";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(13, 80);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(29, 16);
            this.radioButton6.TabIndex = 52;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "4";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(13, 58);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(29, 16);
            this.radioButton5.TabIndex = 51;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "3";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(13, 34);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(29, 16);
            this.radioButton4.TabIndex = 50;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "2";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(13, 12);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(29, 16);
            this.radioButton3.TabIndex = 49;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "1";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton16);
            this.panel1.Controls.Add(this.radioButton15);
            this.panel1.Controls.Add(this.radioButton14);
            this.panel1.Controls.Add(this.radioButton13);
            this.panel1.Location = new System.Drawing.Point(178, 297);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(49, 112);
            this.panel1.TabIndex = 63;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.radioButton16.Location = new System.Drawing.Point(7, 75);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(46, 16);
            this.radioButton16.TabIndex = 62;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "Gray";
            this.radioButton16.UseVisualStyleBackColor = true;
            this.radioButton16.CheckedChanged += new System.EventHandler(this.radioButton16_CheckedChanged_1);
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.radioButton15.Location = new System.Drawing.Point(7, 51);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(42, 16);
            this.radioButton15.TabIndex = 61;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "Red";
            this.radioButton15.UseVisualStyleBackColor = true;
            this.radioButton15.CheckedChanged += new System.EventHandler(this.radioButton15_CheckedChanged_1);
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.radioButton14.Location = new System.Drawing.Point(7, 29);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(43, 16);
            this.radioButton14.TabIndex = 60;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "blue";
            this.radioButton14.UseVisualStyleBackColor = true;
            this.radioButton14.CheckedChanged += new System.EventHandler(this.radioButton14_CheckedChanged_1);
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(7, 7);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(57, 16);
            this.radioButton13.TabIndex = 59;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Default";
            this.radioButton13.UseVisualStyleBackColor = true;
            this.radioButton13.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged_1);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button4.Location = new System.Drawing.Point(2, 605);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(505, 71);
            this.button4.TabIndex = 48;
            this.button4.Text = "Update data";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button5.Location = new System.Drawing.Point(373, 528);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(134, 71);
            this.button5.TabIndex = 47;
            this.button5.Text = "Enter";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button6.Location = new System.Drawing.Point(163, 528);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(203, 71);
            this.button6.TabIndex = 46;
            this.button6.Text = "Page Down";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button7.Location = new System.Drawing.Point(4, 528);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(153, 71);
            this.button7.TabIndex = 45;
            this.button7.Text = "Page Up";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(21, 199);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(76, 22);
            this.textBox6.TabIndex = 40;
            this.textBox6.Text = "6";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(21, 159);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(76, 22);
            this.textBox5.TabIndex = 39;
            this.textBox5.Text = "5";
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(22, 121);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(76, 22);
            this.textBox4.TabIndex = 38;
            this.textBox4.Text = "4";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(21, 84);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(76, 22);
            this.textBox3.TabIndex = 37;
            this.textBox3.Text = "3";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(22, 46);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(76, 22);
            this.textBox2.TabIndex = 36;
            this.textBox2.Text = "2";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(21, 11);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(76, 22);
            this.textBox1.TabIndex = 35;
            this.textBox1.Text = "1";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(12, 12);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(500, 62);
            this.textBox18.TabIndex = 45;
            this.textBox18.Text = "20";
            this.textBox18.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(548, 19);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(75, 16);
            this.radioButton1.TabIndex = 46;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "No Display";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(548, 42);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(73, 16);
            this.radioButton2.TabIndex = 47;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Switch Job";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(758, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 24);
            this.label13.TabIndex = 48;
            // 
            // radioButton31
            // 
            this.radioButton31.AutoSize = true;
            this.radioButton31.Location = new System.Drawing.Point(12, 9);
            this.radioButton31.Name = "radioButton31";
            this.radioButton31.Size = new System.Drawing.Size(82, 16);
            this.radioButton31.TabIndex = 49;
            this.radioButton31.TabStop = true;
            this.radioButton31.Text = "Pg_Call_Job";
            this.radioButton31.UseVisualStyleBackColor = true;
            this.radioButton31.CheckedChanged += new System.EventHandler(this.radioButton31_CheckedChanged_1);
            // 
            // radioButton32
            // 
            this.radioButton32.AutoSize = true;
            this.radioButton32.Location = new System.Drawing.Point(12, 28);
            this.radioButton32.Name = "radioButton32";
            this.radioButton32.Size = new System.Drawing.Size(57, 16);
            this.radioButton32.TabIndex = 73;
            this.radioButton32.TabStop = true;
            this.radioButton32.Text = "Page21";
            this.radioButton32.UseVisualStyleBackColor = true;
            this.radioButton32.CheckedChanged += new System.EventHandler(this.radioButton32_CheckedChanged);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.radioButton32);
            this.panel6.Controls.Add(this.radioButton31);
            this.panel6.Location = new System.Drawing.Point(638, 10);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(80, 65);
            this.panel6.TabIndex = 74;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(13, 146);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(29, 16);
            this.radioButton11.TabIndex = 56;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "7";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(48, 12);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(29, 16);
            this.radioButton12.TabIndex = 73;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "8";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Location = new System.Drawing.Point(48, 36);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(29, 16);
            this.radioButton23.TabIndex = 74;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "9";
            this.radioButton23.UseVisualStyleBackColor = true;
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Location = new System.Drawing.Point(48, 58);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(35, 16);
            this.radioButton24.TabIndex = 75;
            this.radioButton24.TabStop = true;
            this.radioButton24.Text = "10";
            this.radioButton24.UseVisualStyleBackColor = true;
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Location = new System.Drawing.Point(48, 80);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(35, 16);
            this.radioButton25.TabIndex = 76;
            this.radioButton25.TabStop = true;
            this.radioButton25.Text = "11";
            this.radioButton25.UseVisualStyleBackColor = true;
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Location = new System.Drawing.Point(48, 102);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(35, 16);
            this.radioButton26.TabIndex = 77;
            this.radioButton26.TabStop = true;
            this.radioButton26.Text = "12";
            this.radioButton26.UseVisualStyleBackColor = true;
            // 
            // radioButton33
            // 
            this.radioButton33.AutoSize = true;
            this.radioButton33.Location = new System.Drawing.Point(48, 124);
            this.radioButton33.Name = "radioButton33";
            this.radioButton33.Size = new System.Drawing.Size(35, 16);
            this.radioButton33.TabIndex = 78;
            this.radioButton33.TabStop = true;
            this.radioButton33.Text = "13";
            this.radioButton33.UseVisualStyleBackColor = true;
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(48, 146);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(35, 16);
            this.radioButton34.TabIndex = 79;
            this.radioButton34.TabStop = true;
            this.radioButton34.Text = "14";
            this.radioButton34.UseVisualStyleBackColor = true;
            // 
            // radioButton35
            // 
            this.radioButton35.AutoSize = true;
            this.radioButton35.Location = new System.Drawing.Point(81, 12);
            this.radioButton35.Name = "radioButton35";
            this.radioButton35.Size = new System.Drawing.Size(35, 16);
            this.radioButton35.TabIndex = 80;
            this.radioButton35.TabStop = true;
            this.radioButton35.Text = "15";
            this.radioButton35.UseVisualStyleBackColor = true;
            // 
            // radioButton36
            // 
            this.radioButton36.AutoSize = true;
            this.radioButton36.Location = new System.Drawing.Point(81, 34);
            this.radioButton36.Name = "radioButton36";
            this.radioButton36.Size = new System.Drawing.Size(35, 16);
            this.radioButton36.TabIndex = 81;
            this.radioButton36.TabStop = true;
            this.radioButton36.Text = "16";
            this.radioButton36.UseVisualStyleBackColor = true;
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(81, 56);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(35, 16);
            this.radioButton37.TabIndex = 82;
            this.radioButton37.TabStop = true;
            this.radioButton37.Text = "17";
            this.radioButton37.UseVisualStyleBackColor = true;
            // 
            // radioButton38
            // 
            this.radioButton38.AutoSize = true;
            this.radioButton38.Location = new System.Drawing.Point(81, 78);
            this.radioButton38.Name = "radioButton38";
            this.radioButton38.Size = new System.Drawing.Size(35, 16);
            this.radioButton38.TabIndex = 83;
            this.radioButton38.TabStop = true;
            this.radioButton38.Text = "18";
            this.radioButton38.UseVisualStyleBackColor = true;
            // 
            // radioButton39
            // 
            this.radioButton39.AutoSize = true;
            this.radioButton39.Location = new System.Drawing.Point(81, 102);
            this.radioButton39.Name = "radioButton39";
            this.radioButton39.Size = new System.Drawing.Size(35, 16);
            this.radioButton39.TabIndex = 84;
            this.radioButton39.TabStop = true;
            this.radioButton39.Text = "19";
            this.radioButton39.UseVisualStyleBackColor = true;
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(81, 124);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(35, 16);
            this.radioButton40.TabIndex = 85;
            this.radioButton40.TabStop = true;
            this.radioButton40.Text = "20";
            this.radioButton40.UseVisualStyleBackColor = true;
            // 
            // radioButton41
            // 
            this.radioButton41.AutoSize = true;
            this.radioButton41.Location = new System.Drawing.Point(81, 146);
            this.radioButton41.Name = "radioButton41";
            this.radioButton41.Size = new System.Drawing.Size(35, 16);
            this.radioButton41.TabIndex = 86;
            this.radioButton41.TabStop = true;
            this.radioButton41.Text = "21";
            this.radioButton41.UseVisualStyleBackColor = true;
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Location = new System.Drawing.Point(114, 12);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(35, 16);
            this.radioButton42.TabIndex = 87;
            this.radioButton42.TabStop = true;
            this.radioButton42.Text = "22";
            this.radioButton42.UseVisualStyleBackColor = true;
            // 
            // radioButton43
            // 
            this.radioButton43.AutoSize = true;
            this.radioButton43.Location = new System.Drawing.Point(113, 34);
            this.radioButton43.Name = "radioButton43";
            this.radioButton43.Size = new System.Drawing.Size(35, 16);
            this.radioButton43.TabIndex = 88;
            this.radioButton43.TabStop = true;
            this.radioButton43.Text = "23";
            this.radioButton43.UseVisualStyleBackColor = true;
            // 
            // radioButton44
            // 
            this.radioButton44.AutoSize = true;
            this.radioButton44.Location = new System.Drawing.Point(113, 58);
            this.radioButton44.Name = "radioButton44";
            this.radioButton44.Size = new System.Drawing.Size(35, 16);
            this.radioButton44.TabIndex = 89;
            this.radioButton44.TabStop = true;
            this.radioButton44.Text = "24";
            this.radioButton44.UseVisualStyleBackColor = true;
            // 
            // radioButton45
            // 
            this.radioButton45.AutoSize = true;
            this.radioButton45.Location = new System.Drawing.Point(114, 80);
            this.radioButton45.Name = "radioButton45";
            this.radioButton45.Size = new System.Drawing.Size(35, 16);
            this.radioButton45.TabIndex = 90;
            this.radioButton45.TabStop = true;
            this.radioButton45.Text = "25";
            this.radioButton45.UseVisualStyleBackColor = true;
            // 
            // radioButton46
            // 
            this.radioButton46.AutoSize = true;
            this.radioButton46.Location = new System.Drawing.Point(114, 100);
            this.radioButton46.Name = "radioButton46";
            this.radioButton46.Size = new System.Drawing.Size(35, 16);
            this.radioButton46.TabIndex = 91;
            this.radioButton46.TabStop = true;
            this.radioButton46.Text = "26";
            this.radioButton46.UseVisualStyleBackColor = true;
            // 
            // radioButton47
            // 
            this.radioButton47.AutoSize = true;
            this.radioButton47.Location = new System.Drawing.Point(113, 124);
            this.radioButton47.Name = "radioButton47";
            this.radioButton47.Size = new System.Drawing.Size(35, 16);
            this.radioButton47.TabIndex = 92;
            this.radioButton47.TabStop = true;
            this.radioButton47.Text = "27";
            this.radioButton47.UseVisualStyleBackColor = true;
            // 
            // radioButton48
            // 
            this.radioButton48.AutoSize = true;
            this.radioButton48.Location = new System.Drawing.Point(113, 146);
            this.radioButton48.Name = "radioButton48";
            this.radioButton48.Size = new System.Drawing.Size(35, 16);
            this.radioButton48.TabIndex = 93;
            this.radioButton48.TabStop = true;
            this.radioButton48.Text = "28";
            this.radioButton48.UseVisualStyleBackColor = true;
            // 
            // radioButton49
            // 
            this.radioButton49.AutoSize = true;
            this.radioButton49.Location = new System.Drawing.Point(42, 31);
            this.radioButton49.Name = "radioButton49";
            this.radioButton49.Size = new System.Drawing.Size(29, 16);
            this.radioButton49.TabIndex = 60;
            this.radioButton49.TabStop = true;
            this.radioButton49.Text = "9";
            this.radioButton49.UseVisualStyleBackColor = true;
            // 
            // radioButton50
            // 
            this.radioButton50.AutoSize = true;
            this.radioButton50.Location = new System.Drawing.Point(42, 51);
            this.radioButton50.Name = "radioButton50";
            this.radioButton50.Size = new System.Drawing.Size(35, 16);
            this.radioButton50.TabIndex = 61;
            this.radioButton50.TabStop = true;
            this.radioButton50.Text = "10";
            this.radioButton50.UseVisualStyleBackColor = true;
            // 
            // radioButton51
            // 
            this.radioButton51.AutoSize = true;
            this.radioButton51.Location = new System.Drawing.Point(42, 73);
            this.radioButton51.Name = "radioButton51";
            this.radioButton51.Size = new System.Drawing.Size(35, 16);
            this.radioButton51.TabIndex = 62;
            this.radioButton51.TabStop = true;
            this.radioButton51.Text = "11";
            this.radioButton51.UseVisualStyleBackColor = true;
            // 
            // radioButton52
            // 
            this.radioButton52.AutoSize = true;
            this.radioButton52.Location = new System.Drawing.Point(42, 95);
            this.radioButton52.Name = "radioButton52";
            this.radioButton52.Size = new System.Drawing.Size(35, 16);
            this.radioButton52.TabIndex = 63;
            this.radioButton52.TabStop = true;
            this.radioButton52.Text = "12";
            this.radioButton52.UseVisualStyleBackColor = true;
            // 
            // radioButton53
            // 
            this.radioButton53.AutoSize = true;
            this.radioButton53.Location = new System.Drawing.Point(42, 117);
            this.radioButton53.Name = "radioButton53";
            this.radioButton53.Size = new System.Drawing.Size(35, 16);
            this.radioButton53.TabIndex = 64;
            this.radioButton53.TabStop = true;
            this.radioButton53.Text = "13";
            this.radioButton53.UseVisualStyleBackColor = true;
            // 
            // radioButton54
            // 
            this.radioButton54.AutoSize = true;
            this.radioButton54.Location = new System.Drawing.Point(42, 139);
            this.radioButton54.Name = "radioButton54";
            this.radioButton54.Size = new System.Drawing.Size(35, 16);
            this.radioButton54.TabIndex = 65;
            this.radioButton54.TabStop = true;
            this.radioButton54.Text = "14";
            this.radioButton54.UseVisualStyleBackColor = true;
            // 
            // radioButton55
            // 
            this.radioButton55.AutoSize = true;
            this.radioButton55.Location = new System.Drawing.Point(77, 8);
            this.radioButton55.Name = "radioButton55";
            this.radioButton55.Size = new System.Drawing.Size(35, 16);
            this.radioButton55.TabIndex = 66;
            this.radioButton55.TabStop = true;
            this.radioButton55.Text = "15";
            this.radioButton55.UseVisualStyleBackColor = true;
            // 
            // radioButton56
            // 
            this.radioButton56.AutoSize = true;
            this.radioButton56.Location = new System.Drawing.Point(77, 31);
            this.radioButton56.Name = "radioButton56";
            this.radioButton56.Size = new System.Drawing.Size(35, 16);
            this.radioButton56.TabIndex = 67;
            this.radioButton56.TabStop = true;
            this.radioButton56.Text = "16";
            this.radioButton56.UseVisualStyleBackColor = true;
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Location = new System.Drawing.Point(77, 53);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(35, 16);
            this.radioButton57.TabIndex = 68;
            this.radioButton57.TabStop = true;
            this.radioButton57.Text = "17";
            this.radioButton57.UseVisualStyleBackColor = true;
            // 
            // radioButton58
            // 
            this.radioButton58.AutoSize = true;
            this.radioButton58.Location = new System.Drawing.Point(77, 75);
            this.radioButton58.Name = "radioButton58";
            this.radioButton58.Size = new System.Drawing.Size(35, 16);
            this.radioButton58.TabIndex = 69;
            this.radioButton58.TabStop = true;
            this.radioButton58.Text = "18";
            this.radioButton58.UseVisualStyleBackColor = true;
            // 
            // radioButton59
            // 
            this.radioButton59.AutoSize = true;
            this.radioButton59.Location = new System.Drawing.Point(77, 95);
            this.radioButton59.Name = "radioButton59";
            this.radioButton59.Size = new System.Drawing.Size(35, 16);
            this.radioButton59.TabIndex = 70;
            this.radioButton59.TabStop = true;
            this.radioButton59.Text = "19";
            this.radioButton59.UseVisualStyleBackColor = true;
            // 
            // radioButton60
            // 
            this.radioButton60.AutoSize = true;
            this.radioButton60.Location = new System.Drawing.Point(77, 117);
            this.radioButton60.Name = "radioButton60";
            this.radioButton60.Size = new System.Drawing.Size(35, 16);
            this.radioButton60.TabIndex = 71;
            this.radioButton60.TabStop = true;
            this.radioButton60.Text = "20";
            this.radioButton60.UseVisualStyleBackColor = true;
            // 
            // radioButton61
            // 
            this.radioButton61.AutoSize = true;
            this.radioButton61.Location = new System.Drawing.Point(77, 139);
            this.radioButton61.Name = "radioButton61";
            this.radioButton61.Size = new System.Drawing.Size(35, 16);
            this.radioButton61.TabIndex = 72;
            this.radioButton61.TabStop = true;
            this.radioButton61.Text = "21";
            this.radioButton61.UseVisualStyleBackColor = true;
            // 
            // radioButton62
            // 
            this.radioButton62.AutoSize = true;
            this.radioButton62.Location = new System.Drawing.Point(115, 7);
            this.radioButton62.Name = "radioButton62";
            this.radioButton62.Size = new System.Drawing.Size(35, 16);
            this.radioButton62.TabIndex = 73;
            this.radioButton62.TabStop = true;
            this.radioButton62.Text = "22";
            this.radioButton62.UseVisualStyleBackColor = true;
            // 
            // radioButton63
            // 
            this.radioButton63.AutoSize = true;
            this.radioButton63.Location = new System.Drawing.Point(115, 31);
            this.radioButton63.Name = "radioButton63";
            this.radioButton63.Size = new System.Drawing.Size(35, 16);
            this.radioButton63.TabIndex = 74;
            this.radioButton63.TabStop = true;
            this.radioButton63.Text = "23";
            this.radioButton63.UseVisualStyleBackColor = true;
            // 
            // radioButton64
            // 
            this.radioButton64.AutoSize = true;
            this.radioButton64.Location = new System.Drawing.Point(115, 53);
            this.radioButton64.Name = "radioButton64";
            this.radioButton64.Size = new System.Drawing.Size(35, 16);
            this.radioButton64.TabIndex = 75;
            this.radioButton64.TabStop = true;
            this.radioButton64.Text = "24";
            this.radioButton64.UseVisualStyleBackColor = true;
            // 
            // radioButton65
            // 
            this.radioButton65.AutoSize = true;
            this.radioButton65.Location = new System.Drawing.Point(115, 75);
            this.radioButton65.Name = "radioButton65";
            this.radioButton65.Size = new System.Drawing.Size(35, 16);
            this.radioButton65.TabIndex = 76;
            this.radioButton65.TabStop = true;
            this.radioButton65.Text = "25";
            this.radioButton65.UseVisualStyleBackColor = true;
            // 
            // radioButton66
            // 
            this.radioButton66.AutoSize = true;
            this.radioButton66.Location = new System.Drawing.Point(115, 98);
            this.radioButton66.Name = "radioButton66";
            this.radioButton66.Size = new System.Drawing.Size(35, 16);
            this.radioButton66.TabIndex = 77;
            this.radioButton66.TabStop = true;
            this.radioButton66.Text = "26";
            this.radioButton66.UseVisualStyleBackColor = true;
            // 
            // radioButton67
            // 
            this.radioButton67.AutoSize = true;
            this.radioButton67.Location = new System.Drawing.Point(115, 117);
            this.radioButton67.Name = "radioButton67";
            this.radioButton67.Size = new System.Drawing.Size(35, 16);
            this.radioButton67.TabIndex = 78;
            this.radioButton67.TabStop = true;
            this.radioButton67.Text = "27";
            this.radioButton67.UseVisualStyleBackColor = true;
            // 
            // radioButton68
            // 
            this.radioButton68.AutoSize = true;
            this.radioButton68.Location = new System.Drawing.Point(115, 139);
            this.radioButton68.Name = "radioButton68";
            this.radioButton68.Size = new System.Drawing.Size(35, 16);
            this.radioButton68.TabIndex = 79;
            this.radioButton68.TabStop = true;
            this.radioButton68.Text = "28";
            this.radioButton68.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(21, 234);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(76, 22);
            this.textBox7.TabIndex = 73;
            this.textBox7.Text = "7";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(123, 11);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(76, 22);
            this.textBox8.TabIndex = 74;
            this.textBox8.Text = "8";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(123, 46);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(76, 22);
            this.textBox9.TabIndex = 75;
            this.textBox9.Text = "9";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(123, 84);
            this.textBox10.Margin = new System.Windows.Forms.Padding(2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(76, 22);
            this.textBox10.TabIndex = 76;
            this.textBox10.Text = "10";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(123, 121);
            this.textBox11.Margin = new System.Windows.Forms.Padding(2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(76, 22);
            this.textBox11.TabIndex = 77;
            this.textBox11.Text = "11";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(123, 159);
            this.textBox12.Margin = new System.Windows.Forms.Padding(2);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(76, 22);
            this.textBox12.TabIndex = 78;
            this.textBox12.Text = "12";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(123, 199);
            this.textBox13.Margin = new System.Windows.Forms.Padding(2);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(76, 22);
            this.textBox13.TabIndex = 79;
            this.textBox13.Text = "13";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(123, 234);
            this.textBox14.Margin = new System.Windows.Forms.Padding(2);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(76, 22);
            this.textBox14.TabIndex = 80;
            this.textBox14.Text = "14";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(228, 11);
            this.textBox15.Margin = new System.Windows.Forms.Padding(2);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(76, 22);
            this.textBox15.TabIndex = 81;
            this.textBox15.Text = "15";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(228, 46);
            this.textBox16.Margin = new System.Windows.Forms.Padding(2);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(76, 22);
            this.textBox16.TabIndex = 82;
            this.textBox16.Text = "16";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(228, 84);
            this.textBox17.Margin = new System.Windows.Forms.Padding(2);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(76, 22);
            this.textBox17.TabIndex = 83;
            this.textBox17.Text = "17";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(228, 121);
            this.textBox19.Margin = new System.Windows.Forms.Padding(2);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(76, 22);
            this.textBox19.TabIndex = 84;
            this.textBox19.Text = "18";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(228, 159);
            this.textBox20.Margin = new System.Windows.Forms.Padding(2);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(76, 22);
            this.textBox20.TabIndex = 85;
            this.textBox20.Text = "19";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(228, 199);
            this.textBox21.Margin = new System.Windows.Forms.Padding(2);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(76, 22);
            this.textBox21.TabIndex = 86;
            this.textBox21.Text = "20";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(228, 234);
            this.textBox22.Margin = new System.Windows.Forms.Padding(2);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(76, 22);
            this.textBox22.TabIndex = 87;
            this.textBox22.Text = "21";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(337, 11);
            this.textBox23.Margin = new System.Windows.Forms.Padding(2);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(76, 22);
            this.textBox23.TabIndex = 88;
            this.textBox23.Text = "22";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(337, 46);
            this.textBox24.Margin = new System.Windows.Forms.Padding(2);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(76, 22);
            this.textBox24.TabIndex = 89;
            this.textBox24.Text = "23";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(337, 84);
            this.textBox25.Margin = new System.Windows.Forms.Padding(2);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(76, 22);
            this.textBox25.TabIndex = 90;
            this.textBox25.Text = "24";
            this.textBox25.TextChanged += new System.EventHandler(this.textBox25_TextChanged);
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(337, 121);
            this.textBox26.Margin = new System.Windows.Forms.Padding(2);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(76, 22);
            this.textBox26.TabIndex = 91;
            this.textBox26.Text = "25";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(337, 159);
            this.textBox27.Margin = new System.Windows.Forms.Padding(2);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(76, 22);
            this.textBox27.TabIndex = 92;
            this.textBox27.Text = "26";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(337, 199);
            this.textBox28.Margin = new System.Windows.Forms.Padding(2);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(76, 22);
            this.textBox28.TabIndex = 93;
            this.textBox28.Text = "27";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(337, 234);
            this.textBox29.Margin = new System.Windows.Forms.Padding(2);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(76, 22);
            this.textBox29.TabIndex = 94;
            this.textBox29.Text = "28";
            // 
            // Pg_Call_Job
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 792);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Pg_Call_Job";
            this.Text = "Pg_Call_Job";
            this.Load += new System.EventHandler(this.Pg_Call_Job_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RadioButton radioButton31;
        private System.Windows.Forms.RadioButton radioButton32;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton43;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.RadioButton radioButton41;
        private System.Windows.Forms.RadioButton radioButton40;
        private System.Windows.Forms.RadioButton radioButton39;
        private System.Windows.Forms.RadioButton radioButton38;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.RadioButton radioButton36;
        private System.Windows.Forms.RadioButton radioButton35;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.RadioButton radioButton33;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton65;
        private System.Windows.Forms.RadioButton radioButton64;
        private System.Windows.Forms.RadioButton radioButton63;
        private System.Windows.Forms.RadioButton radioButton62;
        private System.Windows.Forms.RadioButton radioButton61;
        private System.Windows.Forms.RadioButton radioButton60;
        private System.Windows.Forms.RadioButton radioButton59;
        private System.Windows.Forms.RadioButton radioButton58;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.RadioButton radioButton56;
        private System.Windows.Forms.RadioButton radioButton55;
        private System.Windows.Forms.RadioButton radioButton54;
        private System.Windows.Forms.RadioButton radioButton53;
        private System.Windows.Forms.RadioButton radioButton52;
        private System.Windows.Forms.RadioButton radioButton51;
        private System.Windows.Forms.RadioButton radioButton50;
        private System.Windows.Forms.RadioButton radioButton49;
        private System.Windows.Forms.RadioButton radioButton48;
        private System.Windows.Forms.RadioButton radioButton47;
        private System.Windows.Forms.RadioButton radioButton46;
        private System.Windows.Forms.RadioButton radioButton45;
        private System.Windows.Forms.RadioButton radioButton44;
        private System.Windows.Forms.RadioButton radioButton68;
        private System.Windows.Forms.RadioButton radioButton67;
        private System.Windows.Forms.RadioButton radioButton66;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox29;
    }
}