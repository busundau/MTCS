﻿
namespace SerialHex
{
    partial class Pg_Tool_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(-2, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 71);
            this.button1.TabIndex = 31;
            this.button1.Text = "Page Up";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(157, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(194, 71);
            this.button2.TabIndex = 33;
            this.button2.Text = "Page Down";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.Location = new System.Drawing.Point(357, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 71);
            this.button3.TabIndex = 34;
            this.button3.Text = "Enter";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button4.Location = new System.Drawing.Point(-1, 80);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(505, 71);
            this.button4.TabIndex = 35;
            this.button4.Text = "Update data";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(548, 92);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(352, 747);
            this.richTextBox1.TabIndex = 36;
            this.richTextBox1.Text = "";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label27);
            this.panel4.Controls.Add(this.textBox27);
            this.panel4.Controls.Add(this.textBox28);
            this.panel4.Controls.Add(this.textBox29);
            this.panel4.Controls.Add(this.textBox30);
            this.panel4.Controls.Add(this.textBox31);
            this.panel4.Controls.Add(this.textBox32);
            this.panel4.Controls.Add(this.textBox33);
            this.panel4.Controls.Add(this.textBox34);
            this.panel4.Controls.Add(this.textBox35);
            this.panel4.Controls.Add(this.textBox36);
            this.panel4.Controls.Add(this.textBox37);
            this.panel4.Controls.Add(this.textBox38);
            this.panel4.Controls.Add(this.textBox39);
            this.panel4.Controls.Add(this.textBox40);
            this.panel4.Controls.Add(this.textBox41);
            this.panel4.Controls.Add(this.textBox42);
            this.panel4.Controls.Add(this.textBox43);
            this.panel4.Controls.Add(this.textBox44);
            this.panel4.Controls.Add(this.textBox45);
            this.panel4.Controls.Add(this.textBox46);
            this.panel4.Controls.Add(this.textBox26);
            this.panel4.Controls.Add(this.textBox25);
            this.panel4.Controls.Add(this.textBox24);
            this.panel4.Controls.Add(this.textBox23);
            this.panel4.Controls.Add(this.textBox22);
            this.panel4.Controls.Add(this.textBox21);
            this.panel4.Controls.Add(this.textBox20);
            this.panel4.Controls.Add(this.textBox19);
            this.panel4.Controls.Add(this.textBox17);
            this.panel4.Controls.Add(this.textBox16);
            this.panel4.Controls.Add(this.textBox15);
            this.panel4.Controls.Add(this.textBox14);
            this.panel4.Controls.Add(this.textBox13);
            this.panel4.Controls.Add(this.textBox12);
            this.panel4.Controls.Add(this.textBox11);
            this.panel4.Controls.Add(this.textBox10);
            this.panel4.Controls.Add(this.textBox9);
            this.panel4.Controls.Add(this.textBox8);
            this.panel4.Controls.Add(this.textBox7);
            this.panel4.Controls.Add(this.textBox3);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.textBox6);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.textBox5);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.textBox4);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.textBox2);
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Location = new System.Drawing.Point(8, 92);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(518, 532);
            this.panel4.TabIndex = 43;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.Color.Red;
            this.label30.Location = new System.Drawing.Point(160, 511);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(85, 12);
            this.label30.TabIndex = 126;
            this.label30.Text = "(0~4294967295)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(155, 392);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 125;
            this.label4.Text = "(-127~+128)";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(165, 449);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 12);
            this.label27.TabIndex = 124;
            this.label27.Text = "(-127~+128)";
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox27.Location = new System.Drawing.Point(361, 291);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(45, 36);
            this.textBox27.TabIndex = 121;
            this.textBox27.Text = "$";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox28.Location = new System.Drawing.Point(310, 291);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(45, 36);
            this.textBox28.TabIndex = 120;
            this.textBox28.Text = "_";
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox29.Location = new System.Drawing.Point(259, 291);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(45, 36);
            this.textBox29.TabIndex = 119;
            this.textBox29.Text = "d";
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox30.Location = new System.Drawing.Point(208, 291);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(45, 36);
            this.textBox30.TabIndex = 118;
            this.textBox30.Text = "c";
            // 
            // textBox31
            // 
            this.textBox31.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox31.Location = new System.Drawing.Point(157, 291);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(45, 36);
            this.textBox31.TabIndex = 117;
            this.textBox31.Text = "b";
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox32.Location = new System.Drawing.Point(101, 291);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(45, 36);
            this.textBox32.TabIndex = 116;
            this.textBox32.Text = "a";
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox33.Location = new System.Drawing.Point(412, 249);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(45, 36);
            this.textBox33.TabIndex = 115;
            this.textBox33.Text = "G";
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox34.Location = new System.Drawing.Point(361, 249);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(45, 36);
            this.textBox34.TabIndex = 114;
            this.textBox34.Text = "F";
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox35.Location = new System.Drawing.Point(310, 248);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(45, 36);
            this.textBox35.TabIndex = 113;
            this.textBox35.Text = "E";
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox36.Location = new System.Drawing.Point(259, 249);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(45, 36);
            this.textBox36.TabIndex = 112;
            this.textBox36.Text = "D";
            // 
            // textBox37
            // 
            this.textBox37.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox37.Location = new System.Drawing.Point(208, 249);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(45, 36);
            this.textBox37.TabIndex = 111;
            this.textBox37.Text = "C";
            // 
            // textBox38
            // 
            this.textBox38.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox38.Location = new System.Drawing.Point(157, 249);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(45, 36);
            this.textBox38.TabIndex = 110;
            this.textBox38.Text = "B";
            // 
            // textBox39
            // 
            this.textBox39.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox39.Location = new System.Drawing.Point(101, 249);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(45, 36);
            this.textBox39.TabIndex = 109;
            this.textBox39.Text = "A";
            // 
            // textBox40
            // 
            this.textBox40.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox40.Location = new System.Drawing.Point(412, 207);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(45, 36);
            this.textBox40.TabIndex = 108;
            this.textBox40.Text = "7";
            // 
            // textBox41
            // 
            this.textBox41.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox41.Location = new System.Drawing.Point(361, 206);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(45, 36);
            this.textBox41.TabIndex = 107;
            this.textBox41.Text = "6";
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox42.Location = new System.Drawing.Point(310, 206);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(45, 36);
            this.textBox42.TabIndex = 106;
            this.textBox42.Text = "5";
            // 
            // textBox43
            // 
            this.textBox43.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox43.Location = new System.Drawing.Point(259, 207);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(45, 36);
            this.textBox43.TabIndex = 105;
            this.textBox43.Text = "4";
            // 
            // textBox44
            // 
            this.textBox44.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox44.Location = new System.Drawing.Point(208, 207);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(45, 36);
            this.textBox44.TabIndex = 104;
            this.textBox44.Text = "3";
            // 
            // textBox45
            // 
            this.textBox45.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox45.Location = new System.Drawing.Point(157, 207);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(45, 36);
            this.textBox45.TabIndex = 103;
            this.textBox45.Text = "2";
            // 
            // textBox46
            // 
            this.textBox46.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox46.Location = new System.Drawing.Point(101, 207);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(45, 36);
            this.textBox46.TabIndex = 102;
            this.textBox46.Text = "1";
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox26.Location = new System.Drawing.Point(381, 136);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(45, 36);
            this.textBox26.TabIndex = 101;
            this.textBox26.Text = "$";
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox25.Location = new System.Drawing.Point(330, 136);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(45, 36);
            this.textBox25.TabIndex = 100;
            this.textBox25.Text = "_";
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox24.Location = new System.Drawing.Point(279, 136);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(45, 36);
            this.textBox24.TabIndex = 99;
            this.textBox24.Text = "d";
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox23.Location = new System.Drawing.Point(228, 136);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(45, 36);
            this.textBox23.TabIndex = 98;
            this.textBox23.Text = "c";
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox22.Location = new System.Drawing.Point(177, 136);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(45, 36);
            this.textBox22.TabIndex = 97;
            this.textBox22.Text = "b";
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox21.Location = new System.Drawing.Point(121, 136);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(45, 36);
            this.textBox21.TabIndex = 96;
            this.textBox21.Text = "a";
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox20.Location = new System.Drawing.Point(432, 94);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(45, 36);
            this.textBox20.TabIndex = 95;
            this.textBox20.Text = "G";
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox19.Location = new System.Drawing.Point(381, 94);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(45, 36);
            this.textBox19.TabIndex = 94;
            this.textBox19.Text = "F";
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox17.Location = new System.Drawing.Point(330, 93);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(45, 36);
            this.textBox17.TabIndex = 93;
            this.textBox17.Text = "E";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox16.Location = new System.Drawing.Point(279, 94);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(45, 36);
            this.textBox16.TabIndex = 92;
            this.textBox16.Text = "D";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox15.Location = new System.Drawing.Point(228, 94);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(45, 36);
            this.textBox15.TabIndex = 91;
            this.textBox15.Text = "C";
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox14.Location = new System.Drawing.Point(177, 94);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(45, 36);
            this.textBox14.TabIndex = 90;
            this.textBox14.Text = "B";
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox13.Location = new System.Drawing.Point(121, 94);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(45, 36);
            this.textBox13.TabIndex = 89;
            this.textBox13.Text = "A";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox12.Location = new System.Drawing.Point(432, 52);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(45, 36);
            this.textBox12.TabIndex = 88;
            this.textBox12.Text = "7";
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox11.Location = new System.Drawing.Point(381, 51);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(45, 36);
            this.textBox11.TabIndex = 87;
            this.textBox11.Text = "6";
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox10.Location = new System.Drawing.Point(330, 51);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(45, 36);
            this.textBox10.TabIndex = 86;
            this.textBox10.Text = "5";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox9.Location = new System.Drawing.Point(279, 52);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(45, 36);
            this.textBox9.TabIndex = 85;
            this.textBox9.Text = "4";
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox8.Location = new System.Drawing.Point(228, 52);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(45, 36);
            this.textBox8.TabIndex = 84;
            this.textBox8.Text = "3";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox7.Location = new System.Drawing.Point(177, 52);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(45, 36);
            this.textBox7.TabIndex = 83;
            this.textBox7.Text = "2";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox3.Location = new System.Drawing.Point(121, 52);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(45, 36);
            this.textBox3.TabIndex = 82;
            this.textBox3.Text = "1";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.radioButton3);
            this.panel8.Controls.Add(this.radioButton12);
            this.panel8.Controls.Add(this.radioButton11);
            this.panel8.Location = new System.Drawing.Point(252, 416);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(115, 55);
            this.panel8.TabIndex = 81;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(7, 14);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(99, 16);
            this.radioButton3.TabIndex = 81;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Sign No Display";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged_2);
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(7, 36);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(82, 16);
            this.radioButton12.TabIndex = 80;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "Sign Display";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged_1);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(7, -19);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(99, 16);
            this.radioButton11.TabIndex = 79;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "Sign No Display";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged_1);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(132, 413);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(18, 24);
            this.label14.TabIndex = 78;
            this.label14.Text = "-";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.radioButton8);
            this.panel6.Controls.Add(this.radioButton7);
            this.panel6.Location = new System.Drawing.Point(254, 351);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(128, 60);
            this.panel6.TabIndex = 74;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(15, 29);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(82, 16);
            this.radioButton8.TabIndex = 73;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Sign Display";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged_1);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(15, 7);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(99, 16);
            this.radioButton7.TabIndex = 72;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Sign No Display";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(131, 354);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 24);
            this.label13.TabIndex = 71;
            this.label13.Text = "-";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox6.Location = new System.Drawing.Point(155, 410);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(77, 36);
            this.textBox6.TabIndex = 65;
            this.textBox6.Text = "27";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(13, 413);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(118, 24);
            this.label11.TabIndex = 64;
            this.label11.Text = "Batt . Temp";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox5.Location = new System.Drawing.Point(154, 478);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(170, 36);
            this.textBox5.TabIndex = 63;
            this.textBox5.Text = "123456";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(13, 481);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 24);
            this.label9.TabIndex = 61;
            this.label9.Text = "Tor. Sensor";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox4.Location = new System.Drawing.Point(152, 353);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(77, 36);
            this.textBox4.TabIndex = 59;
            this.textBox4.Text = "39";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(13, 353);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 24);
            this.label7.TabIndex = 58;
            this.label7.Text = "PCB Temp.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(13, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 24);
            this.label5.TabIndex = 56;
            this.label5.Text = "Model";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(13, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 24);
            this.label3.TabIndex = 54;
            this.label3.Text = "S/N";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(172, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 24);
            this.label1.TabIndex = 52;
            this.label1.Text = ".";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.Location = new System.Drawing.Point(200, 10);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(45, 36);
            this.textBox2.TabIndex = 51;
            this.textBox2.Text = "8";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.Location = new System.Drawing.Point(121, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(45, 36);
            this.textBox1.TabIndex = 49;
            this.textBox1.Text = "12";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label21.Location = new System.Drawing.Point(13, 10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(90, 24);
            this.label21.TabIndex = 48;
            this.label21.Text = "FW Ver.";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button4);
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.button1);
            this.panel5.Location = new System.Drawing.Point(6, 630);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(536, 170);
            this.panel5.TabIndex = 44;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(12, 12);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(500, 62);
            this.textBox18.TabIndex = 45;
            this.textBox18.Text = "60";
            this.textBox18.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(12, 9);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(75, 16);
            this.radioButton1.TabIndex = 46;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "No Display";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(11, 31);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(104, 16);
            this.radioButton2.TabIndex = 47;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Tool Information";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton1);
            this.panel1.Controls.Add(this.radioButton2);
            this.panel1.Location = new System.Drawing.Point(529, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(115, 59);
            this.panel1.TabIndex = 48;
            // 
            // Pg_Tool_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 792);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Pg_Tool_Info";
            this.Text = "Pg_Tool_Info";
            this.Load += new System.EventHandler(this.Pg_Tool_Info_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RadioButton radioButton3;
    }
}